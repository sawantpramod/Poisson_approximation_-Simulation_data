"""
Full Reproducible Analysis Pipeline
-----------------------------------
Runs all analyses in sequence and generates a comprehensive report.
"""

import os
import sys
import subprocess
from datetime import datetime
import numpy as np
from scipy import stats


print("=" * 70)
print("THE DATA DECODER: FULL REPRODUCIBLE ANALYSIS")
print("=" * 70)
print(f"Run started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print()

# Create directories
os.makedirs('output/reports', exist_ok=True)
os.makedirs('output/figures', exist_ok=True)

# ------------------------------------------------------------------
# Import and run all modules
# ------------------------------------------------------------------
scripts = [
    '01_frequency_distribution.py',
    '02_normality_tests.py', 
    '03_poisson_binomial_ecommerce.py',
    '04_approximation_breakdown.py'
]

for script in scripts:
    print(f"\n{'='*70}")
    print(f"RUNNING: {script}")
    print('='*70)
    try:
        exec(open(f'src/{script}').read())
    except Exception as e:
        print(f"Error running {script}: {e}")
    print()

# ------------------------------------------------------------------
# Generate summary report
# ------------------------------------------------------------------
print("=" * 70)
print("GENERATING SUMMARY REPORT")
print("=" * 70)

# FIX: Use 'utf-8' encoding to handle all Unicode characters
with open('output/reports/full_analysis_summary.txt', 'w', encoding='utf-8') as f:
    f.write("=" * 70 + "\n")
    f.write("THE DATA DECODER: FULL REPRODUCIBLE ANALYSIS\n")
    f.write("=" * 70 + "\n")
    f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
    
    # Key results from each section
    f.write("1. FREQUENCY DISTRIBUTION\n")
    f.write("-" * 50 + "\n")
    f.write("Exam scores (N=20): 4,5,5,6,6,6,7,7,7,7,7,8,8,8,8,9,9,9,10,10\n")
    f.write("Frequency: 1,2,3,5,4,3,2\n\n")
    
    f.write("2. NORMALITY TESTS\n")
    f.write("-" * 50 + "\n")
    f.write("Shapiro-Wilk: W=0.9615, p=0.575\n")
    f.write("Verdict: Fail to reject H0 (consistent with normality)\n")  # FIXED: Changed H0 to H0
    f.write("Interpretation: No statistically significant evidence of non-normality.\n\n")
    
    # Recompute to ensure values are correct and tied to actual parameters
    LAMBDA_VISITORS = 150
    P_CONVERT = 0.02
    LAMBDA_SALES = LAMBDA_VISITORS * P_CONVERT

    # 3. E-COMMERCE ANALYSIS
    p_zero = stats.poisson.pmf(0, mu=LAMBDA_SALES)
    p_zero_3 = p_zero ** 3
    p_five_exact = stats.binom.pmf(5, n=LAMBDA_VISITORS, p=P_CONVERT)
    p_five_approx = stats.poisson.pmf(5, mu=LAMBDA_SALES)

    f.write("3. E-COMMERCE ANALYSIS\n")
    f.write("-" * 50 + "\n")
    f.write(f"Parameters: lambda_visitors={LAMBDA_VISITORS}, p_convert={P_CONVERT}, lambda_sales={LAMBDA_SALES}\n")
    f.write(f"Zero-sales probability (one hour): {p_zero:.4%} (~1 in {1/p_zero:.0f} hours)\n")
    f.write(f"Three consecutive zero-sales: {p_zero_3:.4%} (~1 in {1/p_zero_3:,.0f})\n")
    f.write(f"P(exactly 5 sales): Exact={p_five_exact:.4%}, Poisson={p_five_approx:.4%}\n\n")

    # 4. APPROXIMATION BREAKDOWN
    # Safe zone
    safe_n, safe_p = 150, 0.02
    safe_lam = safe_n * safe_p
    safe_binom = stats.binom.pmf(np.arange(0, 13), n=safe_n, p=safe_p)
    safe_pois = stats.poisson.pmf(np.arange(0, 13), mu=safe_lam)
    safe_gap = np.abs(safe_binom - safe_pois).max()

    # Severe violation
    severe_n, severe_p = 6, 0.5
    severe_lam = severe_n * severe_p
    severe_binom = stats.binom.pmf(np.arange(0, 8), n=severe_n, p=severe_p)
    severe_pois = stats.poisson.pmf(np.arange(0, 8), mu=severe_lam)
    severe_gap = np.abs(severe_binom - severe_pois).max()

    f.write("4. APPROXIMATION BREAKDOWN\n")
    f.write("-" * 50 + "\n")
    f.write(f"Safe zone (n={safe_n}, p={safe_p}): max gap {safe_gap:.2%}\n")
    f.write(f"Severe violation (n={severe_n}, p={severe_p}): max gap {severe_gap:.2%}\n")
    f.write(f"Conclusion: lambda alone not sufficient; need n large AND p small.\n\n")
    
    f.write("5. KEY INSIGHTS\n")
    f.write("-" * 50 + "\n")
    f.write("1. Data type (discrete vs continuous) dictates model choice\n")
    f.write("2. Statistical significance != practical significance\n")
    f.write("3. Always verify assumptions before applying approximations\n")
    f.write("4. Visual inspection + formal testing provides robust evidence\n")

print("Summary report saved to: output/reports/full_analysis_summary.txt")
print()
print("=" * 70)
print("ANALYSIS COMPLETE!")
print("=" * 70)
print("Output files:")
print("  - Figures: output/figures/")
print("  - Reports: output/reports/")
print("  - Data: data/ecommerce_poisson_binomial_dataset.csv")
print()