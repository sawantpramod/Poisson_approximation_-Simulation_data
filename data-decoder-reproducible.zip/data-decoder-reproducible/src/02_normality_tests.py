"""
Normality Tests on Classroom Data
--------------------------------
Implements Shapiro-Wilk test and discusses Kolmogorov-Smirnov limitations.
"""

import numpy as np
from scipy import stats
import os

# Create output directory if it doesn't exist
os.makedirs('output/reports', exist_ok=True)

# Data
scores = [4, 5, 6, 7, 8, 9, 10]
frequencies = [1, 2, 3, 5, 4, 3, 2]

# Expand frequency table to raw scores
raw_scores = np.array([s for s, f in zip(scores, frequencies) for _ in range(f)])
n = len(raw_scores)

print("=" * 70)
print("NORMALITY TESTS ON EXAM SCORES")
print("=" * 70)
print(f"Sample size (n): {n}")
print(f"Raw scores: {raw_scores.tolist()}")
print()

# ------------------------------------------------------------------
# Shapiro-Wilk Test (recommended for small samples)
# ------------------------------------------------------------------
print("1. SHAPIRO-WILK TEST")
print("-" * 50)
stat, p_value = stats.shapiro(raw_scores)
print(f"Shapiro-Wilk statistic (W): {stat:.4f}")
print(f"p-value                    : {p_value:.4f}")

alpha = 0.05
if p_value > alpha:
    verdict = "Fail to reject H0 - no significant evidence against normality."
    detail = "The data is consistent with a normal distribution at alpha=0.05."
else:
    verdict = "Reject H0 - significant deviation from normality detected."
    detail = "The data shows evidence of non-normality at alpha=0.05."

print(f"Verdict (alpha=0.05): {verdict}")
print(f"Interpretation: {detail}")
print()

# ------------------------------------------------------------------
# Note on Kolmogorov-Smirnov Test
# ------------------------------------------------------------------
print("2. NOTE ON KOLMOGOROV-SMIRNOV TEST")
print("-" * 50)
print("The Kolmogorov-Smirnov test is NOT recommended for this data because:")
print("1. It assumes continuous data (we have discrete scores with ties)")
print("2. It's less powerful than Shapiro-Wilk for small samples")
print("3. It can produce misleading p-values with tied data")
print()
print("-> Shapiro-Wilk is the appropriate test for this dataset.")
print()

# ------------------------------------------------------------------
# Save results to file (with proper encoding)
# ------------------------------------------------------------------
# FIX: Use 'utf-8' encoding to handle all Unicode characters
with open('output/reports/normality_test_results.txt', 'w', encoding='utf-8') as f:
    f.write("=" * 70 + "\n")
    f.write("NORMALITY TEST RESULTS ON EXAM SCORES\n")
    f.write("=" * 70 + "\n\n")
    f.write(f"Sample: {raw_scores.tolist()}\n")
    f.write(f"Sample size: {n}\n\n")
    f.write("Shapiro-Wilk Test:\n")
    f.write(f"  W = {stat:.4f}\n")
    f.write(f"  p = {p_value:.4f}\n")
    f.write(f"  Verdict: {verdict}\n\n")
    f.write("Note: Kolmogorov-Smirnov test was not used because\n")
    f.write("the data has ties (repeated values), which violates\n")
    f.write("the continuous data assumption of the KS test.\n")

print("Saved results -> output/reports/normality_test_results.txt")
print()