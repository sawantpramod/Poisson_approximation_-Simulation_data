"""
Where Poisson Approximation Breaks Down
--------------------------------------
Demonstrates that λ alone doesn't guarantee accuracy - n and p matter.
Shows how Binomial variance differs from Poisson variance when p is not small.
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
import os

# Create output directory if it doesn't exist
os.makedirs('output/figures', exist_ok=True)

print("=" * 70)
print("WHERE POISSON STOPS APPROXIMATING BINOMIAL WELL")
print("=" * 70)

# Scenarios with same λ=3 but different n and p
scenarios = [
    ("Safe zone (article's case)", 150, 0.02),
    ("Borderline", 30, 0.10),
    ("Violation begins", 10, 0.30),
    ("Severe violation (n=6, p=0.5)", 6, 0.50),
]

x_vals = np.arange(0, 8)

print("\nHolding λ = n×p = 3 constant, but varying n and p:")
print("\n" + "-" * 95)
print(f"{'Scenario':<28}{'n':>5}{'p':>7}{'lambda':>9}   Max |Binom-Poisson| gap   Worst k")
print("-" * 95)

results = []
for label, n, p in scenarios:
    lam = n * p
    binom_pmf = stats.binom.pmf(x_vals, n=n, p=p)
    pois_pmf = stats.poisson.pmf(x_vals, mu=lam)
    gap = np.abs(binom_pmf - pois_pmf)
    worst_k = x_vals[np.argmax(gap)]
    max_gap = gap.max()
    results.append((label, n, p, lam, binom_pmf, pois_pmf, max_gap, worst_k))
    print(f"{label:<28}{n:>5}{p:>7.2f}{lam:>9.1f}   {max_gap:>22.4%}   k={worst_k}")

print("\n" + "=" * 70)
print("DETAILED BREAKDOWN: SEVERE VIOLATION CASE")
print("=" * 70)

# Focus on the worst case
label, n, p, lam, binom_pmf, pois_pmf, max_gap, worst_k = results[-1]
print(f"n={n}, p={p:.2f}, λ={lam:.1f}")
print("\nComparing exact Binomial vs Poisson approximation:")
print("-" * 60)
print(f"{'k':>3}{'Exact Binomial':>18}{'Poisson approx':>18}{'Difference':>14}")
print("-" * 60)
for k, bp, pp in zip(x_vals, binom_pmf, pois_pmf):
    print(f"{k:>3}{bp:>18.4%}{pp:>18.4%}{bp-pp:>+14.4%}")
print("-" * 60)
print(f"Maximum gap: {max_gap:.4%} at k={worst_k}")
print()

# Variance explanation
print("\n" + "=" * 70)
print("WHY IT BREAKS: VARIANCE MISMATCH")
print("=" * 70)
print("Binomial variance  = n × p × (1-p)")
print("Poisson variance   = λ = n × p")
print("When p is small, (1-p) ≈ 1, so variances match.")
print("When p grows large, (1-p) shrinks, variances diverge.\n")

print(f"{'Scenario':<28}{'Binomial Var':>16}{'Poisson Var':>16}{'Ratio':>12}")
print("-" * 75)
for label, n, p, lam, *_ in results:
    binom_var = n * p * (1 - p)
    ratio = binom_var / lam
    print(f"{label:<28}{binom_var:>16.4f}{lam:>16.4f}{ratio:>12.3f}")

print("\n→ The Binomial distribution has less variance than Poisson when p is not small.")
print("   This variance gap IS the mechanism behind the PMF differences above.")
print()

# ------------------------------------------------------------------
# Create Visualization
# ------------------------------------------------------------------
print("GENERATING VISUALIZATION...")
print("-" * 50)

fig, ax = plt.subplots(figsize=(10, 6))

# Use the severe violation case
label, n, p, lam, binom_pmf, pois_pmf, max_gap, worst_k = results[-1]

# Bar chart with two series side by side
width = 0.35
x = np.arange(len(x_vals))
bars1 = ax.bar(x - width/2, binom_pmf, width, 
               label=f'Exact Binomial(n={n}, p={p})', color='#4C72B0')
bars2 = ax.bar(x + width/2, pois_pmf, width,
               label=f'Poisson approx ($\lambda={lam:.0f}$)', color='#DD8452')

# Annotate gaps larger than 0.5%
for xi, bp, pp in zip(x, binom_pmf, pois_pmf):
    gap = bp - pp
    if abs(gap) > 0.005:
        y = max(bp, pp) + 0.02
        ax.annotate(f'{gap:+.1%}', xy=(xi, y), 
                    ha='center', fontsize=8, color='#333333')

ax.set_xlabel('Number of successes (k)')
ax.set_ylabel('Probability')
ax.set_title(f'Where the Approximation Breaks: n={n}, p={p} (same $\lambda$={lam:.0f} as article)',
             fontsize=12, pad=14)
ax.set_xticks(x)
ax.set_xticklabels(x_vals)
ax.legend(loc='upper right')
ax.grid(axis='y', linestyle='--', alpha=0.4)

# Add explanatory note
fig.text(0.5, -0.12,
         "Article's safe-zone (n=150, p=0.02, λ=3): max gap just 0.23%\n"
         "Here (n=6, p=0.5, λ=3): gap peaks at 8.85% (k=3)\n"
         "Same λ, very different agreement: need n large AND p small, not λ alone.",
         ha='center', fontsize=9, color='#444444')

plt.tight_layout()
plt.savefig('output/figures/approximation_breakdown.png', dpi=150, bbox_inches='tight')
print("Saved chart -> output/figures/approximation_breakdown.png")
plt.show()