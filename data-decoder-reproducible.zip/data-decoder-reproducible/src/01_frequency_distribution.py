"""
Frequency Distribution of Exam Scores
-------------------------------------
Classroom case study: 20 students take a 10-mark test.
Creates frequency table and bar chart.
"""

import matplotlib.pyplot as plt
import numpy as np
import os

# Create output directory if it doesn't exist
os.makedirs('output/figures', exist_ok=True)

# Data
scores = [4, 5, 6, 7, 8, 9, 10]
frequencies = [1, 2, 3, 5, 4, 3, 2]
total_n = sum(frequencies)

# 1. Print the frequency table
print("=" * 60)
print("FREQUENCY DISTRIBUTION OF EXAM SCORES")
print("=" * 60)
print("Frequency Table")
print("+" + "-" * 20 + "+")
print(f"| {'Score (x)':^10} | {'Frequency (f)':^10} |")
print("+" + "-" * 20 + "+")
for x, f in zip(scores, frequencies):
    print(f"| {x:^10} | {f:^10} |")
print("+" + "-" * 20 + "+")
print(f"| {'Total (N)':^10} | {total_n:^10} |")
print("+" + "-" * 20 + "+")
print()

# 2. Calculate descriptive statistics
mean_score = np.average(scores, weights=frequencies)
median_score = np.median([s for s, f in zip(scores, frequencies) for _ in range(f)])
print(f"Mean score: {mean_score:.2f}")
print(f"Median score: {median_score:.1f}")
print(f"Total students: {total_n}")
print()

# 3. Create the vertical bar chart
fig, ax = plt.subplots(figsize=(8, 5))
bars = ax.bar(scores, frequencies, color='skyblue', edgecolor='black', width=0.6)

# Customize the chart
ax.set_xlabel('Score (x)', fontsize=12)
ax.set_ylabel('Frequency (f)', fontsize=12)
ax.set_title('Frequency Distribution of Exam Scores (N=20)', fontsize=14)
ax.set_xticks(scores)
ax.set_yticks(range(0, max(frequencies) + 2))
ax.set_ylim(0, max(frequencies) + 1.5)

# Add frequency values on top of bars
for bar, freq in zip(bars, frequencies):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1,
            str(freq), ha='center', va='bottom', fontsize=10)

# Add grid for readability
ax.grid(axis='y', linestyle='--', alpha=0.7)

# Save figure
plt.tight_layout()
plt.savefig('output/figures/frequency_distribution.png', dpi=150, bbox_inches='tight')
print("Saved chart -> output/figures/frequency_distribution.png")
plt.show()
print()

# 4. Verify bell-shaped appearance
print("Visual inspection: The distribution shows a peak at score 7")
print("with frequencies climbing 1→2→3→5 and dropping 5→4→3→2.")
print("This is roughly bell-shaped (unimodal and roughly symmetric).")
print()