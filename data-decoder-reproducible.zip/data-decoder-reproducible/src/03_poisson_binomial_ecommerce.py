"""
E-Commerce Deep Dive: Poisson Meets Binomial
-------------------------------------------
Simulates e-commerce traffic and sales data.
Tests "zero sales" panic scenario and compares exact vs approximate probabilities.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
import os

# Create output directories
os.makedirs('output/figures', exist_ok=True)
os.makedirs('data', exist_ok=True)

np.random.seed(42)

# ------------------------------------------------------------------
# Scenario Parameters
# ------------------------------------------------------------------
LAMBDA_VISITORS = 150     # average visitors/hour
P_CONVERT = 0.02          # historical conversion rate
LAMBDA_SALES = LAMBDA_VISITORS * P_CONVERT  # = 3
N_HOURS = 500

print("=" * 70)
print("E-COMMERCE ANALYSIS: POISSON MEETS BINOMIAL")
print("=" * 70)
print(f"Average visitors/hour  : {LAMBDA_VISITORS}")
print(f"Conversion rate        : {P_CONVERT:.0%}")
print(f"Expected sales/hour    : {LAMBDA_SALES:.1f}")
print(f"Number of hours        : {N_HOURS}")
print()

# ------------------------------------------------------------------
# The "Zero Sales" Panic - Quantified
# ------------------------------------------------------------------
print("1. THE ZERO SALES PANIC")
print("-" * 50)

# Exact Binomial probability
p_zero_exact = stats.binom.pmf(0, n=LAMBDA_VISITORS, p=P_CONVERT)
# Poisson approximation
p_zero_approx = stats.poisson.pmf(0, mu=LAMBDA_SALES)

print(f"P(0 sales in ONE hour):")
print(f"  Exact Binomial    : {p_zero_exact:.4%}")
print(f"  Poisson approx    : {p_zero_approx:.4%}")
print(f"  ~1 in {1/p_zero_approx:.0f} hours (unlucky, but common)")

# Consecutive zero sales
p_zero_2 = p_zero_approx ** 2
p_zero_3 = p_zero_approx ** 3
p_zero_4 = p_zero_approx ** 4
p_zero_5 = p_zero_approx ** 5

# FIXED: Correct format specifiers for percentages
print(f"\nConsecutive zero-sales probabilities:")
print(f"  1 hour  : {p_zero_approx:.4%}  (~1 in {1/p_zero_approx:,.0f})")
print(f"  2 hours : {p_zero_2:.4%}  (~1 in {1/p_zero_2:,.0f})")
print(f"  3 hours : {p_zero_3:.4%}  (~1 in {1/p_zero_3:,.0f})")
print(f"  4 hours : {p_zero_4:.4%}  (~1 in {1/p_zero_4:,.0f})")
print(f"  5 hours : {p_zero_5:.4%}  (~1 in {1/p_zero_5:,.0f})")  # FIXED: removed extra 'f'

# Probability of at least one zero in a 24-hour day
p_at_least_one_zero_day = 1 - (1 - p_zero_approx) ** 24
print(f"\nP(at least one zero-sales hour in 24h): {p_at_least_one_zero_day:.4%}")
print("-> A single zero-sales hour is NOT a red flag; it's expected almost daily.")

print(f"\nP(3 consecutive zero-sales hours): {p_zero_3:.4%}")
print("-> This IS a genuine signal (about 1 in 8,100 three-hour sequences)")
print()

# ------------------------------------------------------------------
# "Exactly 5 Sales This Hour" - Exact vs Approximation
# ------------------------------------------------------------------
print("2. EXACT SALES PROBABILITY (k=5)")
print("-" * 50)

p_five_exact = stats.binom.pmf(5, n=LAMBDA_VISITORS, p=P_CONVERT)
p_five_approx = stats.poisson.pmf(5, mu=LAMBDA_SALES)

print(f"P(exactly 5 sales in an hour):")
print(f"  Exact Binomial    : {p_five_exact:.4%}")
print(f"  Poisson approx    : {p_five_approx:.4%}")
print(f"  Difference        : {abs(p_five_exact - p_five_approx):.4%}")

print("\n-> Nearly identical! The approximation works well when n is large and p is small.")
print()

# ------------------------------------------------------------------
# Generate Simulated Dataset
# ------------------------------------------------------------------
print("3. GENERATING SIMULATED DATASET")
print("-" * 50)

hourly_visitors = np.random.poisson(lam=LAMBDA_VISITORS, size=N_HOURS)
hourly_sales = np.random.binomial(n=hourly_visitors, p=P_CONVERT)

df = pd.DataFrame({
    'hour_id': range(1, N_HOURS + 1),
    'visitors': hourly_visitors,
    'sales': hourly_sales,
    'conversion_rate': (hourly_sales / hourly_visitors).round(4)
})

# Save to CSV
df.to_csv('data/ecommerce_poisson_binomial_dataset.csv', index=False)
print(f"Saved dataset -> data/ecommerce_poisson_binomial_dataset.csv")
print(f"Simulated average sales/hour: {hourly_sales.mean():.2f} (target: {LAMBDA_SALES})")
print()

# ------------------------------------------------------------------
# Visualizations
# ------------------------------------------------------------------
print("4. GENERATING VISUALIZATIONS")
print("-" * 50)

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Panel 1: Exact Binomial vs Poisson Approximation
x = np.arange(0, 13)
pmf_binom = stats.binom.pmf(x, n=LAMBDA_VISITORS, p=P_CONVERT)
pmf_pois = stats.poisson.pmf(x, mu=LAMBDA_SALES)

width = 0.35
axes[0].bar(x - width/2, pmf_binom, width, 
            label='Exact Binomial(150, 0.02)', color='#4C72B0')
axes[0].bar(x + width/2, pmf_pois, width,
            label='Poisson approx (lambda=3)', color='#DD8452')
axes[0].set_xlabel('Sales in the hour')
axes[0].set_ylabel('Probability')
axes[0].set_title('Sales per Hour: Exact vs. Poisson Approximation')
axes[0].legend()
axes[0].grid(axis='y', linestyle='--', alpha=0.4)

# Panel 2: Probability of N consecutive zero-sales hours
n_consec = np.arange(1, 6)
p_consec = p_zero_approx ** n_consec
bars = axes[1].bar(n_consec, p_consec, color='#55A868')
for bar, prob in zip(bars, p_consec):
    axes[1].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.001,
                 f'{prob:.4%}', ha='center', va='bottom', fontsize=9)
axes[1].set_xlabel('Consecutive zero-sales hours')
axes[1].set_ylabel('Probability')
axes[1].set_title('How Rare Is a Zero-Sales Streak?')
axes[1].set_xticks(n_consec)
axes[1].grid(axis='y', linestyle='--', alpha=0.4)

plt.tight_layout()
plt.savefig('output/figures/poisson_binomial_comparison.png', dpi=150, bbox_inches='tight')
print("Saved chart -> output/figures/poisson_binomial_comparison.png")
plt.show()

# ------------------------------------------------------------------
# Summary Statistics
# ------------------------------------------------------------------
print("\n5. SUMMARY STATISTICS")
print("-" * 50)
print(f"Total hours simulated: {N_HOURS}")
print(f"Average visitors/hour: {df['visitors'].mean():.1f}")
print(f"Average sales/hour: {df['sales'].mean():.2f}")
print(f"Conversion rate (observed): {df['sales'].sum() / df['visitors'].sum():.4%}")
print(f"Zero-sales hours: {sum(df['sales'] == 0)} ({sum(df['sales'] == 0) / N_HOURS:.1%})")